import { useEffect } from 'react'
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom'
import useAuthStore from './store/authStore'
import api from './lib/api'
import Login          from './pages/Login'
import Register       from './pages/Register'
import Home           from './pages/Home'
import Navbar         from './components/layout/Navbar'
import PageLayout     from './components/layout/PageLayout'
import Shop           from './pages/Shop'
import ProductDetail  from './pages/ProductDetail'
import Cart           from './pages/Cart'
import Checkout       from './pages/Checkout'
import Orders         from './pages/Orders'
import AdminDashboard from './pages/AdminDashboard'
import AdminRoute     from './components/AdminRoute'
import Profile        from './pages/Profile'
import AddressBook    from './pages/AddressBook'
import ChangePassword from './pages/ChnagePassword'
import ToastProvider  from './components/ui/ToastProvider'

function ProtectedLayout({ children }) {
  const { user, isLoading } = useAuthStore()
  if (isLoading) return null
  if (!user) return <Navigate to="/login" replace />
  return (
    <>
      <Navbar />
      <PageLayout>{children}</PageLayout>
    </>
  )
}

function PublicLayout({ children }) {
  return (
    <>
      <Navbar />
      <PageLayout>{children}</PageLayout>
    </>
  )
}

function App() {
  const { setUser, clearUser, isLoading } = useAuthStore()

  useEffect(() => {
    const token = localStorage.getItem('token')
    if (!token) {
      clearUser()
      return
    }
    const checkAuth = async () => {
      try {
        const res = await api.get('/user')   // ✅ correct Laravel endpoint
        setUser(res.data)
      } catch {
        clearUser()
      }
    }
    checkAuth()
  }, [])

  if (isLoading) return (
    <div className="min-h-screen flex items-center justify-center bg-white">
      <p className="text-gray-400 text-sm tracking-widest uppercase animate-pulse">
        Loading...
      </p>
    </div>
  )

  return (
    <Router>
      <ToastProvider />
      <Routes>
        {/* Auth */}
        <Route path="/login"    element={<Login />} />
        <Route path="/register" element={<Register />} />

        {/* Public */}
        <Route path="/home"        element={<PublicLayout><Home /></PublicLayout>} />
        <Route path="/shop"        element={<PublicLayout><Shop /></PublicLayout>} />
        <Route path="/product/:id" element={<PublicLayout><ProductDetail /></PublicLayout>} />

        {/* Protected */}
        <Route path="/cart"            element={<ProtectedLayout><Cart /></ProtectedLayout>} />
        <Route path="/checkout"        element={<ProtectedLayout><Checkout /></ProtectedLayout>} />
        <Route path="/orders"          element={<ProtectedLayout><Orders /></ProtectedLayout>} />
        <Route path="/profile"         element={<ProtectedLayout><Profile /></ProtectedLayout>} />
        <Route path="/address-book"    element={<ProtectedLayout><AddressBook /></ProtectedLayout>} />
        <Route path="/change-password" element={<ProtectedLayout><ChangePassword /></ProtectedLayout>} />

        {/* Admin */}
        <Route path="/admin" element={
          <ProtectedLayout>
            <AdminRoute><AdminDashboard /></AdminRoute>
          </ProtectedLayout>
        } />

        <Route path="/" element={<Navigate to="/home" replace />} />
      </Routes>
    </Router>
  )
}

export default App