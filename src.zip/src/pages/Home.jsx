import { useEffect, useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faMedal, faTruck, faHeadset, faEnvelope, faPhone, faLocationDot, faArrowRight, faStar, faShield } from '@fortawesome/free-solid-svg-icons';
import api from '../lib/api';
import ProductCard from '../components/product/ProductCard';
import PageTransition from '../components/ui/PageTransition';

export default function Home() {
  const location = useLocation();
  const [featured, setFeatured] = useState([]);
  const [brands, setBrands] = useState([]);

  useEffect(() => {
    // ✅ Fixed: /products returns paginated object, /brands is separate route
    Promise.all([
      api.get('/products?per_page=4'),
      api.get('/brands'),
    ])
      .then(([productsRes, brandsRes]) => {
        // ✅ Fixed: Laravel paginates → products are in products.data
        setFeatured(productsRes.data.products?.data || []);
        // ✅ Fixed: Laravel returns { brands: [...] }
        setBrands(brandsRes.data.brands || []);
      })
      .catch(err => console.error(err));
  }, []);

  useEffect(() => {
    if (location.hash === '#featured-products') document.getElementById('featured-products')?.scrollIntoView({ behavior: 'smooth' });
    else if (location.hash === '#about') document.getElementById('about')?.scrollIntoView({ behavior: 'smooth' });
    else if (location.hash === '#contact') document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' });
  }, [location]);

  return (
    <PageTransition>

      {/* Hero */}
      <div className="relative bg-gradient-to-r from-brand-900 via-brand-800 to-brand-900 text-white overflow-hidden rounded-3xl">
        <div className="absolute inset-0 bg-[url('/pattern.png')] opacity-5 mix-blend-overlay" />
        <div className="container-premium py-24 md:py-32 text-center relative z-10">
          <h1 className="text-5xl md:text-6xl font-mono font-light tracking-wide">Men's Fashion Collection</h1>
          <p className="text-xl text-brand-100 mt-4 font-mono">Discover timeless elegance and modern style</p>
        </div>
      </div>

      {/* Brand Strip */}
      {brands.length > 0 && (
        <div className="bg-premium-light py-12 border-b border-brand-100">
          <div className="container-premium">
            <p className="text-center text-xs font-semibold tracking-wider text-brand-400 uppercase mb-6">Shop by Brand</p>
            <div className="flex flex-wrap justify-center items-center gap-6">
              {brands.map((brand) => (
                <Link key={brand.id} to={`/shop?brand_id=${brand.id}`} className="px-6 py-2 text-sm font-medium text-brand-700 bg-white border border-brand-200 rounded-full shadow-sm hover:shadow-md transition">
                  {brand.name}
                </Link>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Featured Products */}
      <div id="featured-products" className="bg-white py-16">
        <div className="container-premium">
          <div className="text-center mb-12">
            <span className="text-xs font-semibold tracking-widest text-brand-400 uppercase">Curated Selection</span>
            <h2 className="text-3xl md:text-4xl font-light text-brand-800 mt-2">Featured Collection</h2>
            <div className="w-12 h-px bg-brand-300 mx-auto mt-4" />
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-x-6 gap-y-12">
            {featured.map((product) => <ProductCard key={product.id} product={product} />)}
          </div>
          <div className="flex justify-center mt-12">
            <Link to="/shop" className="inline-flex items-center gap-2 text-sm font-medium text-brand-600 border-b border-brand-300 pb-1 hover:text-brand-800 hover:border-brand-800 transition">
              VIEW ALL PRODUCTS
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5l7 7-7 7" /></svg>
            </Link>
          </div>
        </div>
      </div>

      {/* ABOUT */}
      <div id="about" className="bg-white py-24 border-t border-brand-100">
        <div className="container-premium">
          <div className="flex items-center gap-3 mb-16">
            <div className="w-10 h-px bg-brand-300" />
            <span className="text-xs font-semibold tracking-widest text-brand-400 uppercase">Our Story</span>
          </div>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div>
              <h2 className="text-4xl md:text-5xl font-light text-brand-900 leading-tight mb-6">
                Crafted for the<br /><em className="italic">modern gentleman</em>
              </h2>
              <p className="text-brand-500 leading-relaxed mb-8">
                We believe that great style doesn't have to be complicated. Every piece in our collection is carefully selected to combine timeless elegance with modern sensibility — clothing that works as hard as you do.
              </p>
              <div className="grid grid-cols-2 gap-6">
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 bg-brand-100 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                    <FontAwesomeIcon icon={faMedal} className="text-brand-600 text-xs" />
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-brand-800">Premium Quality</p>
                    <p className="text-xs text-brand-500 mt-1">Sourced from the finest materials</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 bg-brand-100 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                    <FontAwesomeIcon icon={faTruck} className="text-brand-600 text-xs" />
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-brand-800">Fast Delivery</p>
                    <p className="text-xs text-brand-500 mt-1">1–3 day local delivery</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 bg-brand-100 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                    <FontAwesomeIcon icon={faShield} className="text-brand-600 text-xs" />
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-brand-800">2-Year Warranty</p>
                    <p className="text-xs text-brand-500 mt-1">Quality you can count on</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 bg-brand-100 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                    <FontAwesomeIcon icon={faHeadset} className="text-brand-600 text-xs" />
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-brand-800">24/7 Support</p>
                    <p className="text-xs text-brand-500 mt-1">Always here to help</p>
                  </div>
                </div>
              </div>
            </div>
            <div className="relative">
              <div className="aspect-[4/5] rounded-2xl overflow-hidden bg-brand-100">
                <img src="/src/assets/about-page-image.jpg" alt="About us" className="w-full h-full object-cover" />
              </div>
              <div className="absolute -bottom-6 -left-6 bg-white rounded-2xl shadow-xl p-5 border border-brand-100">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-brand-900 rounded-full flex items-center justify-center">
                    <FontAwesomeIcon icon={faStar} className="text-white text-sm" />
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-brand-900">4.9 / 5.0</p>
                    <p className="text-xs text-brand-500">1,200+ reviews</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* CONTACT */}
      <div id="contact" className="bg-brand-50 py-20 border-t border-brand-100">
        <div className="container-premium">
          <div className="text-center mb-12">
            <span className="text-xs font-semibold tracking-widest text-brand-400 uppercase">Get in Touch</span>
            <h2 className="text-3xl md:text-4xl font-light text-brand-800 mt-2">Contact Us</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-3xl mx-auto">
            <div className="text-center">
              <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center mx-auto mb-3 shadow-sm border border-brand-100">
                <FontAwesomeIcon icon={faPhone} className="text-brand-600" />
              </div>
              <p className="text-sm font-semibold text-brand-800">Phone</p>
              <p className="text-sm text-brand-500 mt-1">+855 12 345 678</p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center mx-auto mb-3 shadow-sm border border-brand-100">
                <FontAwesomeIcon icon={faEnvelope} className="text-brand-600" />
              </div>
              <p className="text-sm font-semibold text-brand-800">Email</p>
              <p className="text-sm text-brand-500 mt-1">hello@mensstore.com</p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center mx-auto mb-3 shadow-sm border border-brand-100">
                <FontAwesomeIcon icon={faLocationDot} className="text-brand-600" />
              </div>
              <p className="text-sm font-semibold text-brand-800">Location</p>
              <p className="text-sm text-brand-500 mt-1">Phnom Penh, Cambodia</p>
            </div>
          </div>
        </div>
      </div>

    </PageTransition>
  );
}